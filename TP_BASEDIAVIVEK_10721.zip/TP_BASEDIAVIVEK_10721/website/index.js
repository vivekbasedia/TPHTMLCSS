function showAlert() 
{
    var myText = "Hello World";
    alert (myText);
}

function SwitchButtons(buttonId) {
  var hideBtn, showBtn, menuToggle;
  if (buttonId == 'button1') {
    menuToggle = 'menu2';
    showBtn = 'button2';
    hideBtn = 'button1';
  } else {
    menuToggle = 'menu3';
    showBtn = 'button1';
    hideBtn = 'button2';
  }
  
  // document.getElementById(menuToggle).toggle(); //step 1: toggle menu
  document.getElementById(hideBtn).style.display = 'none'; //step 2 :additional feature hide button
  document.getElementById(showBtn).style.display = ''; //step 3:additional feature show button


}




function findPrime(){
//get the input value
                var num = document.getElementById('num').value;
                var c = 0;
 
                //loop till i equals to $num
                for (i = 1; i <= num; i++) {
                    //check if the $num is divisible by itself and 1
                    // % modules will give the reminder value, so if the reminder is 0 then it is divisible
                    if (num % i == 0) {
                        //increment the value of c
                        c = c + 1;
                    }
                }
 
                //if the value of c is 2 then it is a prime number
                //because a prime number should be exactly divisible by 2 times only (itself and 1)
                if (c == 2) {
                    document.getElementById('result').innerHTML = num + ' is a Prime number';
                    alert(document.getElementById('result').innerHTML = num + ' is a Prime number');
                }else{
                    document.getElementById('result').innerHTML = num + ' is NOT a Prime number';
                    alert(document.getElementById('result').innerHTML = num + ' is NOT a Prime number');
                }
            }   




         function asynccall(){
          const Url='http://localhost:8081';
          var name = document.getElementById("fullname").value;
          console.log(name);
         

          var age = document.getElementById("age").value;
          const user={fullname:'name',age:age}
          
                    axios({
            method:'post',
            url:Url,
            data:{fullname:name,
            age:age
            }
          })

  .then(function (response) {
    document.getElementById("ans2").innerHTML = response.data;
    console.log(response);
    var a = response.data
    alert(a);
  })
  .catch(function (error) 
  {
    console.log(error);
    var b = error.data
    alert(b);


 })

}         